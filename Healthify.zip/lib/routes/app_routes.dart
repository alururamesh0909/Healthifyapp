import 'package:flutter/material.dart';
import 'package:mani_s_application4/presentation/android_large_one_one_screen/android_large_one_one_screen.dart';
import 'package:mani_s_application4/presentation/android_large_one_screen/android_large_one_screen.dart';
import 'package:mani_s_application4/presentation/android_large_one_two_screen/android_large_one_two_screen.dart';
import 'package:mani_s_application4/presentation/app_navigation_screen/app_navigation_screen.dart';

class AppRoutes {
  static const String androidLargeOneOneScreen =
      '/android_large_one_one_screen';

  static const String androidLargeOneScreen = '/android_large_one_screen';

  static const String androidLargeOneTwoScreen =
      '/android_large_one_two_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static const String initialRoute = '/initialRoute';

  static Map<String, WidgetBuilder> get routes => {
        androidLargeOneOneScreen: AndroidLargeOneOneScreen.builder,
        androidLargeOneScreen: AndroidLargeOneScreen.builder,
        androidLargeOneTwoScreen: AndroidLargeOneTwoScreen.builder,
        appNavigationScreen: AppNavigationScreen.builder,
        initialRoute: AndroidLargeOneOneScreen.builder
      };
}
