class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Android Large - One Two images
  static String imgArrowDown = '$imagePath/img_arrow_down.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
