final Map<String, String> enUs = {
  // Android Large - One One Screen
  "lbl_medalert": "MedAlert..!",
  "lbl_medicine_list": "Medicine list",
  "lbl_welcome": "Welcome...",
  "msg_going_to_expire": "Going to expire...!",
  "msg_medicines_expired": "Medicines expired !",

  // Android Large - One Screen
  "lbl_add": "Add",
  "lbl_date": "Date",
  "lbl_expiry_date": "Expiry date:",
  "lbl_medicine_list2": "Medicine List..",
  "lbl_medicine_name": "Medicine name:",
  "lbl_name": "Name",
  "msg_enter_expiry_date": "enter expiry date....",
  "msg_enter_medicine": "enter medicine ...",

  // Android Large - One Two Screen
  "msg_medicine_expired": "Medicine expired..!",

// Network Error String
  "msg_network_err": "Network Error",
  "msg_something_went_wrong": "Something Went Wrong!",
};
