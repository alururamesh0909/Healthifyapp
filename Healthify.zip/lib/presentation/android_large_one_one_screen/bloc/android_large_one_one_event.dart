// ignore_for_file: must_be_immutable

part of 'android_large_one_one_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///AndroidLargeOneOne widget.
///
/// Events must be immutable and implement the [Equatable] interface.
@immutable
abstract class AndroidLargeOneOneEvent extends Equatable {}

/// Event that is dispatched when the AndroidLargeOneOne widget is first created.
class AndroidLargeOneOneInitialEvent extends AndroidLargeOneOneEvent {
  @override
  List<Object?> get props => [];
}
