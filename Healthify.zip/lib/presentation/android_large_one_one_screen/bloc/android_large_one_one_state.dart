// ignore_for_file: must_be_immutable

part of 'android_large_one_one_bloc.dart';

/// Represents the state of AndroidLargeOneOne in the application.
class AndroidLargeOneOneState extends Equatable {
  AndroidLargeOneOneState({
    this.editTextController,
    this.editTextController1,
    this.androidLargeOneOneModelObj,
  });

  TextEditingController? editTextController;

  TextEditingController? editTextController1;

  AndroidLargeOneOneModel? androidLargeOneOneModelObj;

  @override
  List<Object?> get props => [
        editTextController,
        editTextController1,
        androidLargeOneOneModelObj,
      ];
  AndroidLargeOneOneState copyWith({
    TextEditingController? editTextController,
    TextEditingController? editTextController1,
    AndroidLargeOneOneModel? androidLargeOneOneModelObj,
  }) {
    return AndroidLargeOneOneState(
      editTextController: editTextController ?? this.editTextController,
      editTextController1: editTextController1 ?? this.editTextController1,
      androidLargeOneOneModelObj:
          androidLargeOneOneModelObj ?? this.androidLargeOneOneModelObj,
    );
  }
}
