import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:mani_s_application4/presentation/android_large_one_one_screen/models/android_large_one_one_model.dart';
part 'android_large_one_one_event.dart';
part 'android_large_one_one_state.dart';

/// A bloc that manages the state of a AndroidLargeOneOne according to the event that is dispatched to it.
class AndroidLargeOneOneBloc
    extends Bloc<AndroidLargeOneOneEvent, AndroidLargeOneOneState> {
  AndroidLargeOneOneBloc(AndroidLargeOneOneState initialState)
      : super(initialState) {
    on<AndroidLargeOneOneInitialEvent>(_onInitialize);
  }

  _onInitialize(
    AndroidLargeOneOneInitialEvent event,
    Emitter<AndroidLargeOneOneState> emit,
  ) async {
    emit(state.copyWith(
        editTextController: TextEditingController(),
        editTextController1: TextEditingController()));
  }
}
