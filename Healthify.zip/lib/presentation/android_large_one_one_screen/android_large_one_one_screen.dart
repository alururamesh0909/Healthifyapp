import 'bloc/android_large_one_one_bloc.dart';
import 'models/android_large_one_one_model.dart';
import 'package:flutter/material.dart';
import 'package:mani_s_application4/core/app_export.dart';
import 'package:mani_s_application4/widgets/custom_elevated_button.dart';
import 'package:mani_s_application4/widgets/custom_text_form_field.dart';

class AndroidLargeOneOneScreen extends StatelessWidget {
  const AndroidLargeOneOneScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<AndroidLargeOneOneBloc>(
        create: (context) => AndroidLargeOneOneBloc(AndroidLargeOneOneState(
            androidLargeOneOneModelObj: AndroidLargeOneOneModel()))
          ..add(AndroidLargeOneOneInitialEvent()),
        child: AndroidLargeOneOneScreen());
  }

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: SizedBox(
                width: double.maxFinite,
                child: Column(children: [
                  _buildMedAlertSection(context),
                  SizedBox(height: 20.v),
                  _buildWelcomeSection(context),
                  SizedBox(height: 63.v),
                  CustomElevatedButton(
                      text: "lbl_medicine_list".tr,
                      margin: EdgeInsets.only(left: 20.h, right: 23.h),
                      buttonStyle: CustomButtonStyles.none,
                      decoration:
                          CustomButtonStyles.gradientIndigoAToPrimaryDecoration,
                      onPressed: () {
                        navigatetoList(context);
                      }),
                  SizedBox(height: 47.v),
                  CustomElevatedButton(
                      text: "msg_medicines_expired".tr,
                      margin: EdgeInsets.only(left: 20.h, right: 23.h),
                      buttonStyle: CustomButtonStyles.none,
                      decoration: CustomButtonStyles
                          .gradientIndigoAToErrorContainerDecoration,
                      onPressed: () {
                        navigatetoExpired(context);
                      }),
                  SizedBox(height: 5.v)
                ]))));
  }

  /// Section Widget
  Widget _buildMedAlertSection(BuildContext context) {
    return Container(
        width: double.maxFinite,
        padding: EdgeInsets.symmetric(horizontal: 18.h, vertical: 13.v),
        decoration: AppDecoration.fillOnPrimaryContainer,
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              SizedBox(height: 28.v),
              Text("lbl_medalert".tr, style: theme.textTheme.displaySmall)
            ]));
  }

  /// Section Widget
  Widget _buildWelcomeSection(BuildContext context) {
    return Container(
        padding: EdgeInsets.symmetric(horizontal: 20.h),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text("lbl_welcome".tr, style: CustomTextStyles.titleLargeBlack900),
          SizedBox(height: 21.v),
          Container(
              width: 317.h,
              margin: EdgeInsets.only(right: 3.h),
              padding: EdgeInsets.symmetric(horizontal: 15.h, vertical: 16.v),
              decoration: AppDecoration.fillRedA
                  .copyWith(borderRadius: BorderRadiusStyle.roundedBorder10),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Align(
                    alignment: Alignment.centerLeft,
                    child: Text("msg_going_to_expire".tr,
                        style: theme.textTheme.headlineSmall)),
                SizedBox(height: 10.v),
                Padding(
                    padding: EdgeInsets.only(left: 7.h, right: 10.h),
                    child: BlocSelector<AndroidLargeOneOneBloc,
                            AndroidLargeOneOneState, TextEditingController?>(
                        selector: (state) => state.editTextController,
                        builder: (context, editTextController) {
                          return CustomTextFormField(
                              controller: editTextController,
                              borderDecoration:
                                  TextFormFieldStyleHelper.fillGray,
                              fillColor: appTheme.gray300);
                        })),
                SizedBox(height: 39.v),
                Padding(
                    padding: EdgeInsets.only(left: 7.h, right: 10.h),
                    child: BlocSelector<AndroidLargeOneOneBloc,
                            AndroidLargeOneOneState, TextEditingController?>(
                        selector: (state) => state.editTextController1,
                        builder: (context, editTextController1) {
                          return CustomTextFormField(
                              controller: editTextController1,
                              textInputAction: TextInputAction.done,
                              borderDecoration:
                                  TextFormFieldStyleHelper.fillGray1,
                              fillColor: appTheme.gray200);
                        })),
                SizedBox(height: 27.v),
                Container(
                    height: 43.v,
                    width: 270.h,
                    decoration: BoxDecoration(color: appTheme.gray20001)),
                SizedBox(height: 9.v)
              ]))
        ]));
  }

  /// Navigates to the androidLargeOneScreen when the action is triggered.
  navigatetoList(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.androidLargeOneScreen,
    );
  }

  /// Navigates to the androidLargeOneTwoScreen when the action is triggered.
  navigatetoExpired(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.androidLargeOneTwoScreen,
    );
  }
}
