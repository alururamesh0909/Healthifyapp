// ignore_for_file: must_be_immutable

part of 'android_large_one_two_bloc.dart';

/// Represents the state of AndroidLargeOneTwo in the application.
class AndroidLargeOneTwoState extends Equatable {
  AndroidLargeOneTwoState({
    this.editTextController,
    this.androidLargeOneTwoModelObj,
  });

  TextEditingController? editTextController;

  AndroidLargeOneTwoModel? androidLargeOneTwoModelObj;

  @override
  List<Object?> get props => [
        editTextController,
        androidLargeOneTwoModelObj,
      ];
  AndroidLargeOneTwoState copyWith({
    TextEditingController? editTextController,
    AndroidLargeOneTwoModel? androidLargeOneTwoModelObj,
  }) {
    return AndroidLargeOneTwoState(
      editTextController: editTextController ?? this.editTextController,
      androidLargeOneTwoModelObj:
          androidLargeOneTwoModelObj ?? this.androidLargeOneTwoModelObj,
    );
  }
}
