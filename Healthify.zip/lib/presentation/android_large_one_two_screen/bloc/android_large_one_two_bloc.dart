import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:mani_s_application4/presentation/android_large_one_two_screen/models/android_large_one_two_model.dart';
part 'android_large_one_two_event.dart';
part 'android_large_one_two_state.dart';

/// A bloc that manages the state of a AndroidLargeOneTwo according to the event that is dispatched to it.
class AndroidLargeOneTwoBloc
    extends Bloc<AndroidLargeOneTwoEvent, AndroidLargeOneTwoState> {
  AndroidLargeOneTwoBloc(AndroidLargeOneTwoState initialState)
      : super(initialState) {
    on<AndroidLargeOneTwoInitialEvent>(_onInitialize);
  }

  _onInitialize(
    AndroidLargeOneTwoInitialEvent event,
    Emitter<AndroidLargeOneTwoState> emit,
  ) async {
    emit(state.copyWith(
      editTextController: TextEditingController(),
    ));
  }
}
