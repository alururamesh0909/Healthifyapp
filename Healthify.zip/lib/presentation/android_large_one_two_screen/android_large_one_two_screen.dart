import 'bloc/android_large_one_two_bloc.dart';
import 'models/android_large_one_two_model.dart';
import 'package:flutter/material.dart';
import 'package:mani_s_application4/core/app_export.dart';
import 'package:mani_s_application4/widgets/app_bar/appbar_leading_image.dart';
import 'package:mani_s_application4/widgets/app_bar/appbar_title.dart';
import 'package:mani_s_application4/widgets/app_bar/custom_app_bar.dart';
import 'package:mani_s_application4/widgets/custom_text_form_field.dart';

class AndroidLargeOneTwoScreen extends StatelessWidget {
  const AndroidLargeOneTwoScreen({Key? key})
      : super(
          key: key,
        );

  static Widget builder(BuildContext context) {
    return BlocProvider<AndroidLargeOneTwoBloc>(
      create: (context) => AndroidLargeOneTwoBloc(AndroidLargeOneTwoState(
        androidLargeOneTwoModelObj: AndroidLargeOneTwoModel(),
      ))
        ..add(AndroidLargeOneTwoInitialEvent()),
      child: AndroidLargeOneTwoScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: _buildAppBar(context),
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(
            horizontal: 29.h,
            vertical: 55.v,
          ),
          child: Column(
            children: [
              BlocSelector<AndroidLargeOneTwoBloc, AndroidLargeOneTwoState,
                  TextEditingController?>(
                selector: (state) => state.editTextController,
                builder: (context, editTextController) {
                  return CustomTextFormField(
                    controller: editTextController,
                    textInputAction: TextInputAction.done,
                  );
                },
              ),
              SizedBox(height: 25.v),
              Container(
                height: 60.v,
                width: 298.h,
                decoration: BoxDecoration(
                  color: theme.colorScheme.primaryContainer,
                  borderRadius: BorderRadius.circular(
                    10.h,
                  ),
                ),
              ),
              SizedBox(height: 25.v),
              Container(
                height: 60.v,
                width: 298.h,
                decoration: BoxDecoration(
                  color: theme.colorScheme.primaryContainer,
                  borderRadius: BorderRadius.circular(
                    10.h,
                  ),
                ),
              ),
              SizedBox(height: 25.v),
              Container(
                height: 60.v,
                width: 298.h,
                decoration: BoxDecoration(
                  color: theme.colorScheme.primaryContainer,
                  borderRadius: BorderRadius.circular(
                    10.h,
                  ),
                ),
              ),
              SizedBox(height: 25.v),
              Container(
                height: 60.v,
                width: 298.h,
                decoration: BoxDecoration(
                  color: theme.colorScheme.primaryContainer,
                  borderRadius: BorderRadius.circular(
                    10.h,
                  ),
                ),
              ),
              SizedBox(height: 5.v),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      leadingWidth: 43.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgArrowDown,
        margin: EdgeInsets.only(
          left: 20.h,
          top: 52.v,
          bottom: 53.v,
        ),
      ),
      centerTitle: true,
      title: AppbarTitle(
        text: "msg_medicine_expired".tr,
      ),
      styleType: Style.bgFill,
    );
  }
}
