// ignore_for_file: must_be_immutable

part of 'android_large_one_bloc.dart';

/// Represents the state of AndroidLargeOne in the application.
class AndroidLargeOneState extends Equatable {
  AndroidLargeOneState({
    this.nameController,
    this.editTextController,
    this.nameController1,
    this.expirydateController,
    this.androidLargeOneModelObj,
  });

  TextEditingController? nameController;

  TextEditingController? editTextController;

  TextEditingController? nameController1;

  TextEditingController? expirydateController;

  AndroidLargeOneModel? androidLargeOneModelObj;

  @override
  List<Object?> get props => [
        nameController,
        editTextController,
        nameController1,
        expirydateController,
        androidLargeOneModelObj,
      ];
  AndroidLargeOneState copyWith({
    TextEditingController? nameController,
    TextEditingController? editTextController,
    TextEditingController? nameController1,
    TextEditingController? expirydateController,
    AndroidLargeOneModel? androidLargeOneModelObj,
  }) {
    return AndroidLargeOneState(
      nameController: nameController ?? this.nameController,
      editTextController: editTextController ?? this.editTextController,
      nameController1: nameController1 ?? this.nameController1,
      expirydateController: expirydateController ?? this.expirydateController,
      androidLargeOneModelObj:
          androidLargeOneModelObj ?? this.androidLargeOneModelObj,
    );
  }
}
