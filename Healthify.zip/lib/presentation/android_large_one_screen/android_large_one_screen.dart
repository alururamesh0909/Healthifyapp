import 'bloc/android_large_one_bloc.dart';
import 'models/android_large_one_model.dart';
import 'package:flutter/material.dart';
import 'package:mani_s_application4/core/app_export.dart';
import 'package:mani_s_application4/widgets/custom_elevated_button.dart';
import 'package:mani_s_application4/widgets/custom_text_form_field.dart';

class AndroidLargeOneScreen extends StatelessWidget {
  const AndroidLargeOneScreen({Key? key})
      : super(
          key: key,
        );

  static Widget builder(BuildContext context) {
    return BlocProvider<AndroidLargeOneBloc>(
      create: (context) => AndroidLargeOneBloc(AndroidLargeOneState(
        androidLargeOneModelObj: AndroidLargeOneModel(),
      ))
        ..add(AndroidLargeOneInitialEvent()),
      child: AndroidLargeOneScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: SizedBox(
          width: double.maxFinite,
          child: Column(
            children: [
              _buildMedicineList(context),
              SizedBox(height: 14.v),
              _buildUserDetails(context),
              SizedBox(height: 13.v),
              _buildMedicineDetails(context),
              SizedBox(height: 15.v),
              _buildExpiryDetails(context),
              SizedBox(height: 24.v),
              CustomElevatedButton(
                height: 42.v,
                width: 65.h,
                text: "lbl_add".tr,
                buttonStyle: CustomButtonStyles.fillDeepPurpleA,
                buttonTextStyle: theme.textTheme.headlineLarge!,
              ),
              SizedBox(height: 5.v),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildMedicineList(BuildContext context) {
    return Container(
      width: double.maxFinite,
      padding: EdgeInsets.symmetric(
        horizontal: 87.h,
        vertical: 41.v,
      ),
      decoration: AppDecoration.fillOnError.copyWith(
        borderRadius: BorderRadiusStyle.customBorderBL10,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(height: 2.v),
          Text(
            "lbl_medicine_list2".tr,
            style: theme.textTheme.headlineLarge,
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildUserDetails(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 9.h),
      child: Column(
        children: [
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: EdgeInsets.only(
                left: 13.h,
                right: 79.h,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Padding(
                    padding: EdgeInsets.only(top: 3.v),
                    child: Text(
                      "lbl_name".tr,
                      style: theme.textTheme.headlineSmall,
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(bottom: 3.v),
                    child: Text(
                      "lbl_date".tr,
                      style: theme.textTheme.headlineSmall,
                    ),
                  ),
                ],
              ),
            ),
          ),
          SizedBox(height: 3.v),
          Padding(
            padding: EdgeInsets.only(left: 6.h),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                BlocSelector<AndroidLargeOneBloc, AndroidLargeOneState,
                    TextEditingController?>(
                  selector: (state) => state.nameController,
                  builder: (context, nameController) {
                    return CustomTextFormField(
                      width: 188.h,
                      controller: nameController,
                    );
                  },
                ),
                BlocSelector<AndroidLargeOneBloc, AndroidLargeOneState,
                    TextEditingController?>(
                  selector: (state) => state.editTextController,
                  builder: (context, editTextController) {
                    return CustomTextFormField(
                      width: 133.h,
                      controller: editTextController,
                    );
                  },
                ),
              ],
            ),
          ),
          SizedBox(height: 12.v),
          Padding(
            padding: EdgeInsets.only(left: 6.h),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  height: 57.v,
                  width: 188.h,
                  decoration: BoxDecoration(
                    color: theme.colorScheme.primaryContainer,
                    borderRadius: BorderRadius.circular(
                      10.h,
                    ),
                  ),
                ),
                Container(
                  height: 57.v,
                  width: 133.h,
                  decoration: BoxDecoration(
                    color: theme.colorScheme.primaryContainer,
                    borderRadius: BorderRadius.circular(
                      10.h,
                    ),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: 14.v),
          Padding(
            padding: EdgeInsets.only(left: 5.h),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  height: 57.v,
                  width: 188.h,
                  decoration: BoxDecoration(
                    color: theme.colorScheme.primaryContainer,
                    borderRadius: BorderRadius.circular(
                      10.h,
                    ),
                  ),
                ),
                Container(
                  height: 57.v,
                  width: 133.h,
                  decoration: BoxDecoration(
                    color: theme.colorScheme.primaryContainer,
                    borderRadius: BorderRadius.circular(
                      10.h,
                    ),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: 16.v),
          Padding(
            padding: EdgeInsets.only(left: 6.h),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  height: 57.v,
                  width: 188.h,
                  margin: EdgeInsets.only(bottom: 1.v),
                  decoration: BoxDecoration(
                    color: theme.colorScheme.primaryContainer,
                    borderRadius: BorderRadius.circular(
                      10.h,
                    ),
                  ),
                ),
                Container(
                  height: 57.v,
                  width: 133.h,
                  decoration: BoxDecoration(
                    color: theme.colorScheme.primaryContainer,
                    borderRadius: BorderRadius.circular(
                      10.h,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildMedicineDetails(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "lbl_medicine_name".tr,
            style: theme.textTheme.headlineSmall,
          ),
          SizedBox(height: 8.v),
          Padding(
            padding: EdgeInsets.only(
              left: 10.h,
              right: 11.h,
            ),
            child: BlocSelector<AndroidLargeOneBloc, AndroidLargeOneState,
                TextEditingController?>(
              selector: (state) => state.nameController1,
              builder: (context, nameController1) {
                return CustomTextFormField(
                  controller: nameController1,
                  hintText: "msg_enter_medicine".tr,
                  alignment: Alignment.center,
                  borderDecoration: TextFormFieldStyleHelper.fillGrayTL10,
                  fillColor: appTheme.gray100,
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildExpiryDetails(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "lbl_expiry_date".tr,
            style: theme.textTheme.headlineSmall,
          ),
          SizedBox(height: 12.v),
          Padding(
            padding: EdgeInsets.only(
              left: 20.h,
              right: 7.h,
            ),
            child: BlocSelector<AndroidLargeOneBloc, AndroidLargeOneState,
                TextEditingController?>(
              selector: (state) => state.expirydateController,
              builder: (context, expirydateController) {
                return CustomTextFormField(
                  controller: expirydateController,
                  hintText: "msg_enter_expiry_date".tr,
                  textInputAction: TextInputAction.done,
                  alignment: Alignment.center,
                  borderDecoration: TextFormFieldStyleHelper.fillGrayTL101,
                  fillColor: appTheme.gray10001,
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
