import 'package:mani_s_application4/core/app_export.dart';

class ApiClient {}
